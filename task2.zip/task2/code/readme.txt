The GUI is build using pyqt5 designer, the UI file is exported and used in the code directly

Run the following command to download the used libiraries:
pip install -r requirements.txt
